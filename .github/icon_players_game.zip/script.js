
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const select = document.getElementById("playerSelect");

ICON_PLAYERS.forEach(p => {
    let opt = document.createElement("option");
    opt.value = p;
    opt.textContent = p;
    select.appendChild(opt);
});

let player = {
    name: ICON_PLAYERS[0],
    x: 50,
    y: 350,
    w: 50,
    h: 50,
    color: "white",
    vy: 0,
    onGround: true
};

select.onchange = () => {
    player.name = select.value;
};

function drawPlayer() {
    ctx.fillStyle = player.color;
    ctx.fillRect(player.x, player.y, player.w, player.h);
    ctx.fillStyle = "yellow";
    ctx.font = "20px Arial";
    ctx.fillText(player.name, player.x - 10, player.y - 10);
}

function update() {
    player.vy += 1.2;
    player.y += player.vy;

    if (player.y >= 350) {
        player.y = 350;
        player.vy = 0;
        player.onGround = true;
    }
}

function loop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    update();
    drawPlayer();
    requestAnimationFrame(loop);
}

document.addEventListener("keydown", (e) => {
    if (e.code === "Space" && player.onGround) {
        player.vy = -20;
        player.onGround = false;
    }
});

loop();
